const mysql = require('mysql2');

// Configuração do banco de dados
const pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'Va@#1978',
    database: 'tela_de_login'
});

// Exporta a pool de conexão
module.exports = pool.promise();
