const db = require('./db');
const readline = require('readline');

// Criando uma interface de leitura
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function pergunta(questao) {
    return new Promise((resolve) => {
        rl.question(questao, (resposta) => resolve(resposta));
    });
}

async function oqueOusuerQuerFazer() {
    try {
        const prompt1 = await pergunta(
            "O que quer fazer? \n1: Inserir usuário\n2: Procurar usuário\n3: Atualizar usuário\n4: Deletar usuário\n5: Visualizar todos os usuários\nOpção: "
        );

        if (prompt1 == 1) {
            const email = await pergunta("Digite por favor seu email: ");
            const senha = await pergunta("Digite por favor sua senha: ");
            const [result] = await db.execute(
                'INSERT INTO usuarios (email, senha) VALUES (?, ?)',
                [email, senha]
            );
            console.log('Usuário criado com ID:', result.insertId);
        } else if (prompt1 == 2) {
            const id = await pergunta("Digite por favor seu ID: ");
            const [rows] = await db.execute(
                'SELECT * FROM usuarios WHERE id = ?',
                [id]
            );
            console.log(rows.length > 0 ? rows[0] : 'Usuário não encontrado.');
        } else if (prompt1 == 3) {
            const id = await pergunta("Digite por favor seu ID: ");
            const newEmail = await pergunta("Digite o novo email: ");
            const newSenha = await pergunta("Digite a nova senha: ");
            const [result] = await db.execute(
                'UPDATE usuarios SET email = ?, senha = ? WHERE id = ?',
                [newEmail, newSenha, id]
            );
            console.log(result.affectedRows > 0 ? 'Usuário atualizado com sucesso.' : 'Usuário não encontrado ou dados não atualizados.');
        } else if (prompt1 == 4) {
            const id = await pergunta("Digite o ID do usuário a ser deletado: ");
            const [result] = await db.execute(
                'DELETE FROM usuarios WHERE id = ?',
                [id]
            );
            console.log(result.affectedRows > 0 ? 'Usuário deletado com sucesso.' : 'Usuário não encontrado.');
        } else if (prompt1 == 5) {
            const [rows] = await db.execute('SELECT * FROM usuarios');
            console.table(rows);
        } else {
            console.log('Opção inválida. Tente novamente.');
        }
    } catch (error) {
        console.error('Erro:', error.message);
    } finally {
        rl.close();
        db.end(); // Fecha o pool de conexões
    }
}

oqueOusuerQuerFazer();
