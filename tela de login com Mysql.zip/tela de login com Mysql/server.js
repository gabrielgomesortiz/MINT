const express = require("express");

const app= express();

let PORT= 3000

app.use(express.static("./public"));

app.listen(PORT, () => {
    console.log('Servidor rodando na porta 3000');
});