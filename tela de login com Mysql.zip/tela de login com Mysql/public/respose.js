function viewPassword() {
    let olho = document.getElementById("olho");
    let olhoFechado = document.getElementById("olhoFechado");
    let inputSenha = document.getElementById("password");

    if (olho.style.display === "none") {
        olho.style.display = "inline";         
        olhoFechado.style.display = "none";    
        inputSenha.type = "password";          
    } else {
        olho.style.display = "none";           
        olhoFechado.style.display = "inline";  
        inputSenha.type = "text";              
    }
}
